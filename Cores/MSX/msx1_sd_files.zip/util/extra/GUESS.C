/*
 * This program generates a checksum for the first 64 words of a given file.
 * The checksum is used by ExecROM to identify the ROM type.
 *
 * (c) 1999 A&L Software
 * based on original idea by Ricardo Bittencourt for BrMSX
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <io.h>
#include <fcntl.h>

int main (int argc, char **argv) {
  int file;
  unsigned char *buffer;
  int crc=0,i;

  buffer=(unsigned char *) malloc (8192);
  file=open (argv[1],O_BINARY|O_RDONLY);
  read (file,buffer,8192);
  close (file);
  for (i=0; i<64; i++) {
   crc+=*((unsigned int*)buffer+i);
  }
  printf ("        db 0                ; %s\n        dw %05xh\n        dw %s\n",argv[1],crc,argv[1]);
  return 0;
}